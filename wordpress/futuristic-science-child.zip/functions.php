<?php
/**
 * Futuristic Science Child theme functions.
 * Loads the Hello Elementor parent styles, the brand child styles,
 * and the brand Google Fonts (Newsreader / Manrope / IBM Plex Mono).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'wp_enqueue_scripts', function () {
	// Parent (Hello Elementor) style
	wp_enqueue_style( 'hello-elementor-parent', get_template_directory_uri() . '/style.css', array(), null );
	// Brand Google Fonts
	wp_enqueue_style(
		'fs-google-fonts',
		'https://fonts.googleapis.com/css2?family=Newsreader:opsz,wght@6..72,400;6..72,500;6..72,600&family=Manrope:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500&display=swap',
		array(),
		null
	);
	// Child (brand) style — loaded last so it wins
	wp_enqueue_style( 'fs-child', get_stylesheet_uri(), array( 'hello-elementor-parent', 'fs-google-fonts' ), '1.2.0' );
}, 20 );

/**
 * ---------------------------------------------------------------------------
 * Branded transactional email (WooCommerce)
 * Fixes the sender name shown in the inbox and the broken header logo.
 * ---------------------------------------------------------------------------
 */

// Sender display name — appears as the "From" name in the inbox.
// (Was showing the mailer default "Email Deliverability".)
add_filter( 'woocommerce_email_from_name', function () {
	return 'Futuristic Science';
}, 99 );

// Fallback for any non-WooCommerce site mail so the brand name is consistent.
add_filter( 'wp_mail_from_name', function () {
	return 'Futuristic Science';
}, 99 );

// Email header logo — serve the brand logo bundled in this theme so the URL
// always resolves to a valid, public asset (the previous header image 404'd,
// which is why it rendered as a broken-image icon).
add_filter( 'option_woocommerce_email_header_image', function () {
	return get_stylesheet_directory_uri() . '/email-logo.png';
} );
add_filter( 'default_option_woocommerce_email_header_image', function () {
	return get_stylesheet_directory_uri() . '/email-logo.png';
} );

// Keep the header logo a sensible size and centered on the dark header.
add_filter( 'woocommerce_email_styles', function ( $css ) {
	$css .= "\n#template_header_image img{ max-width:280px; width:auto; height:auto; margin:0 auto; display:block; }\n";
	return $css;
}, 20 );

// Optional: expose the brand palette to the block editor.
add_action( 'after_setup_theme', function () {
	add_theme_support( 'editor-color-palette', array(
		array( 'name' => 'Gold',  'slug' => 'fs-gold', 'color' => '#C8A24C' ),
		array( 'name' => 'Ink',   'slug' => 'fs-ink',  'color' => '#0B1B33' ),
		array( 'name' => 'Teal',  'slug' => 'fs-teal', 'color' => '#12877F' ),
		array( 'name' => 'White', 'slug' => 'fs-white','color' => '#FFFFFF' ),
	) );
} );
