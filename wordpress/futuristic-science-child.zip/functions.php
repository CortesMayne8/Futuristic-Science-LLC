<?php
/**
 * Futuristic Science Child theme functions.
 * Loads the Hello Elementor parent styles, the brand child styles,
 * and the brand Google Fonts (Newsreader / Manrope / IBM Plex Mono).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'wp_enqueue_scripts', function () {
	// Parent (Hello Elementor) style
	wp_enqueue_style( 'hello-elementor-parent', get_template_directory_uri() . '/style.css', array(), null );
	// Brand Google Fonts
	wp_enqueue_style(
		'fs-google-fonts',
		'https://fonts.googleapis.com/css2?family=Newsreader:opsz,wght@6..72,400;6..72,500;6..72,600&family=Manrope:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500&display=swap',
		array(),
		null
	);
	// Child (brand) style — loaded last so it wins
	wp_enqueue_style( 'fs-child', get_stylesheet_uri(), array( 'hello-elementor-parent', 'fs-google-fonts' ), '1.8.0' );
	// Cart page: +/- quantity stepper enhancement
	if ( function_exists( 'is_cart' ) && is_cart() ) {
		wp_enqueue_script( 'fs-cart-fx', get_stylesheet_directory_uri() . '/cart-fx.js', array(), '1.8.0', true );
	}
}, 20 );

/**
 * Cart page: a small trust row just above the "Proceed to checkout" button.
 */
add_action( 'woocommerce_proceed_to_checkout', function () {
	$shield = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>';
	$badge  = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9 12l2 2 4-4"/></svg>';
	$clock  = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>';
	echo '<div class="fs-cart-trust">'
		. '<span class="fs-trust">' . $shield . esc_html__( 'Secure checkout', 'woocommerce' ) . '</span>'
		. '<span class="fs-trust">' . $badge . 'COA verified</span>'
		. '<span class="fs-trust">' . $clock . 'Ships from USA</span>'
		. '</div>';
}, 15 );

/**
 * ---------------------------------------------------------------------------
 * Branded transactional email (WooCommerce)
 * Fixes the sender name shown in the inbox and the broken header logo.
 * ---------------------------------------------------------------------------
 */

// Sender display name — appears as the "From" name in the inbox.
// (Was showing the mailer default "Email Deliverability".)
add_filter( 'woocommerce_email_from_name', function () {
	return 'Futuristic Science';
}, 99 );

// Fallback for any non-WooCommerce site mail so the brand name is consistent.
add_filter( 'wp_mail_from_name', function () {
	return 'Futuristic Science';
}, 99 );

// Email header logo — serve the brand logo bundled in this theme so the URL
// always resolves to a valid, public asset (the previous header image 404'd,
// which is why it rendered as a broken-image icon).
add_filter( 'option_woocommerce_email_header_image', function () {
	return get_stylesheet_directory_uri() . '/email-logo.png';
} );
add_filter( 'default_option_woocommerce_email_header_image', function () {
	return get_stylesheet_directory_uri() . '/email-logo.png';
} );

// Keep the header logo a sensible size and centered on the dark header.
add_filter( 'woocommerce_email_styles', function ( $css ) {
	$css .= "\n#template_header_image img{ max-width:280px; width:auto; height:auto; margin:0 auto; display:block; }\n";
	return $css;
}, 20 );

/**
 * ---------------------------------------------------------------------------
 * Mini-cart / side-cart price breakdown
 * The slide-out cart showed a single "Subtotal" that silently bundled
 * shipping and tax, so the number didn't match the visible line items.
 * Replace the lone subtotal in WooCommerce's mini-cart with an itemized
 * Subtotal / Shipping / Tax / Total breakdown so the price is transparent.
 *
 * This targets the native WooCommerce mini-cart (used by the Elementor
 * Menu Cart widget, the classic cart widget, and side-cart plugins that
 * render woocommerce_mini_cart()). It degrades gracefully everywhere else.
 * ---------------------------------------------------------------------------
 */
add_action( 'after_setup_theme', function () {
	// Drop WooCommerce's default single "Subtotal" line in the mini-cart...
	remove_action( 'woocommerce_widget_shopping_cart_total', 'woocommerce_widget_shopping_cart_subtotal', 10 );
	// ...and print the full breakdown in its place.
	add_action( 'woocommerce_widget_shopping_cart_total', 'fs_minicart_breakdown', 10 );
} );

if ( ! function_exists( 'fs_minicart_breakdown' ) ) {
	/**
	 * Render an itemized total for the mini-cart. Uses <span>s (not block
	 * elements) because WooCommerce wraps this hook inside a <p>.
	 */
	function fs_minicart_breakdown() {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}
		$cart = WC()->cart;

		$row = function ( $label, $value, $extra = '' ) {
			printf(
				'<span class="fs-mc-row%1$s"><span class="fs-mc-label">%2$s</span><span class="fs-mc-val">%3$s</span></span>',
				$extra ? ' ' . esc_attr( $extra ) : '',
				esc_html( $label ),
				wp_kses_post( $value )
			);
		};

		echo '<span class="fs-minicart-breakdown">';

		// Items subtotal (before shipping/tax).
		$row( __( 'Subtotal', 'woocommerce' ), $cart->get_cart_subtotal() );

		// Shipping — show the amount if it's been calculated, otherwise be
		// honest that it's determined once an address is entered.
		if ( $cart->needs_shipping() ) {
			if ( $cart->show_shipping() && WC()->shipping() ) {
				$row( __( 'Shipping', 'woocommerce' ), $cart->get_cart_shipping_total() );
			} else {
				$row( __( 'Shipping', 'woocommerce' ), __( 'Calculated at checkout', 'woocommerce' ), 'fs-mc-muted' );
			}
		}

		// Tax — only as a separate line when prices are shown excluding tax.
		if ( wc_tax_enabled() && ! $cart->display_prices_including_tax() ) {
			$tax_total = (float) $cart->get_taxes_total();
			if ( $tax_total > 0 ) {
				$row( __( 'Tax', 'woocommerce' ), wc_price( $tax_total ) );
			}
		}

		// Grand total (this is the figure the checkout button charges).
		$row( __( 'Total', 'woocommerce' ), $cart->get_total(), 'fs-mc-total' );

		echo '</span>';
	}
}

// Optional: expose the brand palette to the block editor.
add_action( 'after_setup_theme', function () {
	add_theme_support( 'editor-color-palette', array(
		array( 'name' => 'Gold',  'slug' => 'fs-gold', 'color' => '#C8A24C' ),
		array( 'name' => 'Ink',   'slug' => 'fs-ink',  'color' => '#0B1B33' ),
		array( 'name' => 'Teal',  'slug' => 'fs-teal', 'color' => '#12877F' ),
		array( 'name' => 'White', 'slug' => 'fs-white','color' => '#FFFFFF' ),
	) );
} );

/**
 * ---------------------------------------------------------------------------
 * Checkout hard gate — 21+ / qualified-researcher acknowledgment.
 * Required checkbox just above "Place order"; the order cannot be placed
 * until it is ticked, and the acknowledgment is saved to the order.
 * ---------------------------------------------------------------------------
 */
add_action( 'woocommerce_review_order_before_submit', function () {
	$checked = ( WC()->checkout() && WC()->checkout()->get_value( 'fs_age_researcher' ) ) ? true : false;
	woocommerce_form_field( 'fs_age_researcher', array(
		'type'     => 'checkbox',
		'class'    => array( 'fs-gate-field form-row' ),
		'required' => true,
		'label'    => 'I confirm I am 21 years of age or older and a qualified researcher, and that these products are purchased strictly for laboratory research use only — not for human or animal consumption.',
	), $checked );
}, 9 );

add_action( 'woocommerce_checkout_process', function () {
	if ( empty( $_POST['fs_age_researcher'] ) ) {
		wc_add_notice( __( 'Please confirm you are 21 or older and a qualified researcher before placing your order.', 'woocommerce' ), 'error' );
	}
} );

// Save the acknowledgment on the order (HPOS-safe).
add_action( 'woocommerce_checkout_create_order', function ( $order ) {
	if ( ! empty( $_POST['fs_age_researcher'] ) ) {
		$order->update_meta_data( '_fs_age_researcher_ack', 'yes' );
	}
}, 10, 1 );
