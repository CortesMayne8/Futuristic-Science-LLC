/* Futuristic Science — cart page enhancements.
   Wraps each WooCommerce cart quantity input with - / + buttons and
   nudges the cart to recalculate after a change. Safe no-op elsewhere. */
(function () {
  if (document.body) document.body.classList.add('fs-cart-js');
  else document.addEventListener('DOMContentLoaded', function () { document.body.classList.add('fs-cart-js'); });
  function initSteppers() {
    var boxes = document.querySelectorAll('table.cart td.product-quantity .quantity');
    for (var i = 0; i < boxes.length; i++) {
      (function (q) {
        if (q.getAttribute('data-fs-stepper')) return;
        var input = q.querySelector('input.qty');
        if (!input) return;
        q.setAttribute('data-fs-stepper', '1');

        var minus = document.createElement('button');
        minus.type = 'button';
        minus.className = 'fs-qty-btn fs-qty-minus';
        minus.setAttribute('aria-label', 'Decrease quantity');
        minus.textContent = '−';

        var plus = document.createElement('button');
        plus.type = 'button';
        plus.className = 'fs-qty-btn fs-qty-plus';
        plus.setAttribute('aria-label', 'Increase quantity');
        plus.textContent = '+';

        q.insertBefore(minus, input);
        q.appendChild(plus);

        function step(dir) {
          var stepAttr = parseFloat(input.getAttribute('step')) || 1;
          var min = input.hasAttribute('min') ? parseFloat(input.getAttribute('min')) : 0;
          var maxAttr = input.getAttribute('max');
          var max = (maxAttr !== null && maxAttr !== '') ? parseFloat(maxAttr) : Infinity;
          var val = parseFloat(input.value) || 0;
          val = dir > 0 ? Math.min(max, val + stepAttr) : Math.max(min, val - stepAttr);
          if (val === (parseFloat(input.value) || 0)) return;
          input.value = val;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
          scheduleUpdate();
        }
        minus.addEventListener('click', function () { step(-1); });
        plus.addEventListener('click', function () { step(1); });
      })(boxes[i]);
    }
  }

  var timer;
  function scheduleUpdate() {
    var btn = document.querySelector('[name="update_cart"]');
    if (!btn) return;
    btn.disabled = false;
    clearTimeout(timer);
    // let WooCommerce recalc line + cart totals just like "Update cart"
    timer = setTimeout(function () { btn.disabled = false; btn.click(); }, 650);
  }

  if (document.readyState !== 'loading') initSteppers();
  else document.addEventListener('DOMContentLoaded', initSteppers);

  // re-add steppers after WooCommerce replaces the cart via AJAX
  if (window.jQuery) {
    jQuery(document.body).on('updated_cart_totals updated_wc_div wc_fragments_refreshed', initSteppers);
  } else {
    document.body.addEventListener('updated_cart_totals', initSteppers);
  }
})();
